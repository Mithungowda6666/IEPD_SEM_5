# from django.db import models

# from student.models import Student
# class Course(models.Model):
#    course_name = models.CharField(max_length=50)
#    question_number = models.PositiveIntegerField()
#    total_marks = models.PositiveIntegerField()
#    def __str__(self):
#         return self.course_name

# class Question(models.Model):
#     course=models.ForeignKey(Course,on_delete=models.CASCADE)
#     marks=models.PositiveIntegerField()
#     question=models.CharField(max_length=600)
#     option1=models.CharField(max_length=200)
#     option2=models.CharField(max_length=200)
#     option3=models.CharField(max_length=200)
#     option4=models.CharField(max_length=200)
#     cat=(('Option1','Option1'),('Option2','Option2'),('Option3','Option3'),('Option4','Option4'))
#     answer=models.CharField(max_length=200,choices=cat)

# class Result(models.Model):
#     student = models.ForeignKey(Student,on_delete=models.CASCADE)
#     exam = models.ForeignKey(Course,on_delete=models.CASCADE)
#     marks = models.PositiveIntegerField()
#     date = models.DateTimeField(auto_now=True)

from django.db import models
from student.models import Student

class Course(models.Model):
    course_name = models.CharField(max_length=50)
    question_number = models.PositiveIntegerField()
    total_marks = models.PositiveIntegerField()

    def __str__(self):
        return self.course_name

class Question(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    marks = models.PositiveIntegerField()
    question = models.CharField(max_length=600)
    option1 = models.CharField(max_length=200)
    option2 = models.CharField(max_length=200)
    option3 = models.CharField(max_length=200)
    option4 = models.CharField(max_length=200)
    cat = (('Option1', 'Option1'), ('Option2', 'Option2'), ('Option3', 'Option3'), ('Option4', 'Option4'))
    answer = models.CharField(max_length=200, choices=cat)
    
    def __str__(self):
        return self.question

class Result(models.Model):
    
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    exam = models.ForeignKey(Course, on_delete=models.CASCADE)
    marks = models.PositiveIntegerField()
    date = models.DateTimeField(auto_now=True)

# class ResultDetail(models.Model):
    
#     result = models.ForeignKey(Result, on_delete=models.CASCADE, related_name='details')
#     # question = models.ForeignKey(Question, on_delete=models.CASCADE)
#     question = models.ForeignKey(Question, on_delete=models.CASCADE, verbose_name="Question")
#     student_answer = models.CharField(max_length=255)
#     correct_answer = models.CharField(max_length=255)
#     is_correct = models.BooleanField(default=False)

#     def __str__(self):
#         return f"Detail for Question {self.question} in Result {self.result}"
class ResultDetail(models.Model):
    result = models.ForeignKey(Result, on_delete=models.CASCADE, related_name='details')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, verbose_name="Question")
    student_answer = models.CharField(max_length=255)
    correct_answer = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        # Build a string that includes the question text and the options
        options = [f"{getattr(self.question, f'option{i}')}: {getattr(self.question, f'option{i}')}" for i in range(1, 5)]
        options_text = ", ".join(options)
        return f"Question: {self.question.question}, Options: {options_text}, Answer: {self.student_answer}, Correct: {self.is_correct}"





#    ######



class GeneratedQuestion(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    original_question = models.TextField()
    generated_question = models.TextField()
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Generated Question for {self.student} - {self.course}"
