import groq
from .models import ResultDetail, GeneratedQuestion  # Import GeneratedQuestion model

# Set the API key directly in the code
API_KEY = "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"

# Create a Groq client
client = groq.Client(api_key=API_KEY)

def generate_similar_questions():
    # Fetch incorrect answers from ResultDetail
    incorrect_answers = ResultDetail.objects.filter(is_correct=False)

    generated_questions_list = []  # Changed from 'GeneratedQuestion.append' to using a list

    # If there are incorrect questions, generate similar ones
    if incorrect_answers.exists():
        content = "The student answered the following questions incorrectly:\n\n"

        # Loop through each incorrectly answered question
        for idx, detail in enumerate(incorrect_answers):
            question = detail.question.question
            correct_answer = detail.correct_answer
            student = detail.result.student  # Assuming `Result` has a ForeignKey to `Student`
            course = detail.result.exam  # Assuming `Result` has a ForeignKey to `Course`

            # Formatting the question and correct answer
            content += f"Q{idx + 1}: {question}\n"
            content += f"Correct Answer: {correct_answer}\n\n"

        # Send a request to Groq with the incorrect questions
        completion = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[{
                "role": "user",
                "content": content + "Please generate similar questions for each of the above questions , in questioon mention the four diffrent options and the correct option also."
            }],
            temperature=1,
            max_tokens=1024,
            top_p=1,
            stream=True,
        )

        # Collect the output (new generated similar questions)
        response_content = ""
        for chunk in completion:
            response_content += chunk.choices[0].delta.content or ""

        # Clean and format the response
        response_content = response_content.strip()

        # Store the generated questions
        for new_question in response_content.split('\n'):
            new_question_text = new_question.strip()
            if new_question_text:
                # Create and save a new GeneratedQuestion instance
                GeneratedQuestion.objects.create(
                    student=student,
                    course=course,
                    original_question=content,
                    generated_question=new_question_text
                )
                generated_questions_list.append(new_question_text)  # Append to the list

    return generated_questions_list  # Return the list, not the model
