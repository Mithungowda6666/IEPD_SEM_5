from django.contrib import admin
from .models import Question, Result, ResultDetail,GeneratedQuestion, Course

# Register your models here.
admin.site.register(Question)
admin.site.register(Result)
admin.site.register(ResultDetail)
admin.site.register(GeneratedQuestion)
admin.site.register(Course)